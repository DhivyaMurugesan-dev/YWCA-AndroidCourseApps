package com.example.simplecaculator_nov2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
     private EditText Number1;
     private EditText Number2;
     private TextView Result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Number1 = (EditText)findViewById(R.id.Number1);
       Number2 = (EditText)findViewById(R.id.Number2);
       Result = (TextView) findViewById(R.id.Result);
    }
    public void btnsum(View view){
        int num1 = Integer.parseInt(Number1.getText().toString());
        int num2 = Integer.parseInt(Number2.getText().toString());
        int sum  = num1 + num2;
        Result.setText(String.valueOf(sum));
    }
      public void btnsub(View view){
        int num1 = Integer.parseInt(Number1.getText().toString());
        int num2 = Integer.parseInt(Number2.getText().toString());
        int sub  = num1 - num2;
        Result.setText(String.valueOf(sub));
    }
    public void btnmul(View view){
        int num1 = Integer.parseInt(Number1.getText().toString());
        int num2 = Integer.parseInt(Number2.getText().toString());
        int mul  = num1 * num2;
        Result.setText(String.valueOf(mul));
    }
    public void btndiv(View view){
        int num1 = Integer.parseInt(Number1.getText().toString());
        int num2 = Integer.parseInt(Number2.getText().toString());
        int div  = num1 / num2;
        Result.setText(String.valueOf(div));
    }
    }
